// Altere estes produtos, preços e fotografias conforme o menu da sua doceria.
const produtos = [
  {id:1,nome:"Bolo de chocolate",categoria:"bolos",descricao:"Bolo macio com cobertura de chocolate.",preco:450,foto:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=700&q=80"},
  {id:2,nome:"Bolo de morango",categoria:"bolos",descricao:"Uma combinação delicada de morango e creme.",preco:500,foto:"https://images.unsplash.com/photo-1535141192574-5d4897c12636?auto=format&fit=crop&w=700&q=80"},
  {id:3,nome:"Pudim tradicional",categoria:"pudins",descricao:"Pudim cremoso com calda de caramelo.",preco:180,foto:"https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=700&q=80"},
  {id:4,nome:"Mini pudim",categoria:"pudins",descricao:"Pequeno no tamanho, delicioso no sabor.",preco:100,foto:"https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=700&q=80"},
  {id:5,nome:"Geladinho de morango",categoria:"gelados",descricao:"Refrescante e preparado com fruta.",preco:60,foto:"https://images.unsplash.com/photo-1488900128323-21503983a07e?auto=format&fit=crop&w=700&q=80"},
  {id:6,nome:"Geladinho de chocolate",categoria:"gelados",descricao:"Uma opção cremosa para os dias quentes.",preco:70,foto:"https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=700&q=80"}
];

const lista = document.getElementById("listaProdutos");
const contador = document.getElementById("contador");
const itensCarrinho = document.getElementById("itensCarrinho");
const totalElemento = document.getElementById("total");
const fundoModal = document.getElementById("fundoModal");
let carrinho = [];

function mostrarProdutos(categoria = "todos") {
  const filtrados = categoria === "todos"
    ? produtos
    : produtos.filter(produto => produto.categoria === categoria);

  lista.innerHTML = filtrados.map(produto => `
    <article class="produto">
      <img src="${produto.foto}" alt="${produto.nome}" loading="lazy">
      <div class="produto-conteudo">
        <span class="produto-categoria">${produto.categoria}</span>
        <h3>${produto.nome}</h3>
        <p>${produto.descricao}</p>
        <div class="produto-rodape">
          <span class="preco">${produto.preco} MT</span>
          <button class="adicionar" onclick="adicionarAoCarrinho(${produto.id})">+ Adicionar</button>
        </div>
      </div>
    </article>
  `).join("");
}

function adicionarAoCarrinho(id) {
  const produto = produtos.find(item => item.id === id);
  const existente = carrinho.find(item => item.id === id);

  if (existente) {
    existente.quantidade++;
  } else {
    carrinho.push({...produto, quantidade:1});
  }
  atualizarCarrinho();
}

function removerDoCarrinho(id) {
  carrinho = carrinho.filter(item => item.id !== id);
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const quantidade = carrinho.reduce((soma,item) => soma + item.quantidade, 0);
  const total = carrinho.reduce((soma,item) => soma + item.preco * item.quantidade, 0);

  contador.textContent = quantidade;
  totalElemento.textContent = total.toLocaleString("pt-MZ") + " MT";

  if (carrinho.length === 0) {
    itensCarrinho.innerHTML = '<p class="vazio">A sua sacola ainda está vazia.</p>';
    return;
  }

  itensCarrinho.innerHTML = carrinho.map(item => `
    <div class="item-carrinho">
      <span>${item.nome} × ${item.quantidade}<br>${(item.preco * item.quantidade).toLocaleString("pt-MZ")} MT</span>
      <button onclick="removerDoCarrinho(${item.id})">Remover</button>
    </div>
  `).join("");
}

document.getElementById("filtros").addEventListener("click", evento => {
  const botao = evento.target.closest(".filtro");
  if (!botao) return;
  document.querySelectorAll(".filtro").forEach(item => item.classList.remove("ativo"));
  botao.classList.add("ativo");
  mostrarProdutos(botao.dataset.categoria);
});

document.getElementById("abrirCarrinho").addEventListener("click", () => fundoModal.classList.add("aberto"));
document.getElementById("fecharCarrinho").addEventListener("click", () => fundoModal.classList.remove("aberto"));
fundoModal.addEventListener("click", evento => {
  if (evento.target === fundoModal) fundoModal.classList.remove("aberto");
});

document.getElementById("finalizar").addEventListener("click", () => {
  if (carrinho.length === 0) {
    alert("Adicione pelo menos um doce à sua sacola.");
    return;
  }

  // Substitua pelo número da doceria, com indicativo do país e sem + ou espaços.
  const numeroWhatsApp = "258XXXXXXXXX";
  const linhas = carrinho.map(item => `${item.nome} x${item.quantidade} - ${item.preco * item.quantidade} MT`);
  const total = carrinho.reduce((soma,item) => soma + item.preco * item.quantidade, 0);
  const mensagem = `Olá! Gostaria de fazer esta encomenda:\n${linhas.join("\n")}\nTotal estimado: ${total} MT`;
  window.open(`https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensagem)}`, "_blank");
});

document.getElementById("contactarWhatsApp").addEventListener("click", evento => {
  evento.preventDefault();
  const numeroWhatsApp = "258XXXXXXXXX";
  window.open(`https://wa.me/${numeroWhatsApp}`, "_blank");
});

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("menu").classList.toggle("aberto");
});

document.querySelectorAll("#menu a").forEach(link => {
  link.addEventListener("click", () => document.getElementById("menu").classList.remove("aberto"));
});

mostrarProdutos();
