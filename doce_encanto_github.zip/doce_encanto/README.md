# Doce Encanto — site de doceria

Site estático desenvolvido com HTML, CSS e JavaScript, preparado para publicação no GitHub Pages.

## Como abrir
1. Extraia a pasta `doce_encanto`.
2. Abra a pasta no Visual Studio Code.
3. Abra `index.html` no navegador ou use a extensão Live Server.

## Personalização antes de publicar
- Edite o nome e os textos em `index.html`.
- Edite produtos, descrições, preços e fotografias no início de `js/script.js`.
- Substitua `258XXXXXXXXX` pelo número WhatsApp da doceria, incluindo indicativo do país e sem `+` ou espaços.
- Substitua Instagram, localização e contactos de exemplo.
- Confirme os links das fotografias e use imagens próprias ou autorizadas.

## Publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Envie os ficheiros `index.html`, `css/`, `js/`, `imagens/` e `README.md` para a raiz do repositório.
3. Abra Settings → Pages.
4. Em Build and deployment, selecione Deploy from a branch.
5. Escolha a branch `main` e a pasta `/ (root)`, depois Save.
6. Aguarde a publicação e abra o endereço indicado pelo GitHub Pages.

## Nota
Este é um catálogo demonstrativo com carrinho no navegador e encaminhamento de encomendas para WhatsApp. Não processa pagamentos nem guarda encomendas numa base de dados. Os preços são exemplos em meticais e devem ser confirmados e alterados.
